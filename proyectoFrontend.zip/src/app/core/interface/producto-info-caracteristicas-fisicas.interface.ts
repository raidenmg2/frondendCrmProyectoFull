export interface CaracterisiticasFisicasInterface {
  tipoControles: string;
  color: string;
  puertosConectividad: string;
  dimensiones: string;
  peso: string;
}
