export interface CaracteristicasTecnicasInterface {
    procesador: string;
    memoriaRam: string;
    almacenamiento: string;
    conectividad: string;
    resolucionImagen: string;

}