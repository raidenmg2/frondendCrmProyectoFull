export interface ClientesInfoFinanciera {
    /** se definien las propiedades del objeto en este caso la interface */
        
    actividadEconomica:string

}