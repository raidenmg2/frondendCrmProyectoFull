export interface ClientesInfoContacto {
    /** se definien las propiedades del objeto en este caso la interface */
        
    direccion: string;
    ciudadResidencia:string
    departamentoResidencia: string;
    telefono: Number;
    email:string

}