export interface caracteristicasTecnicas {
    procesador: string;
    memoriaRam: string;
    almacenamiento: string;
    conectividad: string;
    resolucionImagen: string;

}