export interface UsuarioInfoLogin {
    /** se definien las propiedades del objeto en este caso la interface */
        
    login:string,
    password:string,
    rol:string,

}