export interface ClientesInfoBasicaOportunidadInterface {
    /** se definien las propiedades del objeto en este caso la interface */
    _id:string,    
    nombres: string;
    apellidos: string;
    numeroDocumento: string;
    telefono: string;
    email: string;
    

}