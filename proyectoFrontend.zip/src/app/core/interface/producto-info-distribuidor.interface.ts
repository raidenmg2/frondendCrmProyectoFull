export interface DistribuidorInterface {
  nit: string;
  razonSocial: string;
  telefono: number;
  direccion: string;
}
