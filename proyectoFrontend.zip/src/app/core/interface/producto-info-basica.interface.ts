export interface ProductoInfoBasicaInterface {


    /** se definien las propiedades del objeto en este caso la interface */
        
    nombre: string;
    precio: number;
    categoria: string;
    descripcion?:string;
   

}


export interface ProductoInfoBasicaOportunidadInterface {


    /** se definien las propiedades del objeto en este caso la interface */
        
    nombre: string;
    precio: number;
    categoria: string;
    
   

}