export enum ROLES {
    ADMIN = 'ADMIN',
    GERENTE = 'GERENTE',
    USUARIO = 'USUARIO',
    VENDEDOR = 'VENDEDOR',
  }
  