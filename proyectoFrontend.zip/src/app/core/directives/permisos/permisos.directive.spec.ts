import { PermisosDirective } from './permisos.directive';

describe('PermisosDirective', () => {
  it('should create an instance', () => {
    const directive = new PermisosDirective();
    expect(directive).toBeTruthy();
  });
});
