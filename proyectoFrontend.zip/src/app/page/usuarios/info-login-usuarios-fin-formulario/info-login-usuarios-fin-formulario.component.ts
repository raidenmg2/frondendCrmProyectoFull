import { Component } from '@angular/core';

@Component({
  selector: 'app-info-login-usuarios-fin-formulario',
  standalone: true,
  imports: [],
  templateUrl: './info-login-usuarios-fin-formulario.component.html',
  styleUrl: './info-login-usuarios-fin-formulario.component.css'
})
export class InfoLoginUsuariosFinFormularioComponent {

}
