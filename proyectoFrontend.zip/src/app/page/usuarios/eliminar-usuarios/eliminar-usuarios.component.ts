import { Component } from '@angular/core';

@Component({
  selector: 'app-eliminar-usuarios',
  standalone: true,
  imports: [],
  templateUrl: './eliminar-usuarios.component.html',
  styleUrl: './eliminar-usuarios.component.css'
})
export class EliminarUsuariosComponent {

}
