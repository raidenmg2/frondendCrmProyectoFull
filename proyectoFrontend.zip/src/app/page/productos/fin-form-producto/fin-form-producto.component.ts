import { Component } from '@angular/core';

@Component({
  selector: 'app-fin-form-producto',
  standalone: true,
  imports: [],
  templateUrl: './fin-form-producto.component.html',
  styleUrl: './fin-form-producto.component.css'
})
export class FinFormProductoComponent {

}
