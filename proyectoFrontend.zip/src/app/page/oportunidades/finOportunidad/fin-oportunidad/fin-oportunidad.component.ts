import { Component } from '@angular/core';

@Component({
  selector: 'app-fin-oportunidad',
  standalone: true,
  imports: [],
  templateUrl: './fin-oportunidad.component.html',
  styleUrl: './fin-oportunidad.component.css'
})
export class FinOportunidadComponent {

}
