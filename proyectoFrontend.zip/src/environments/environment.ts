/** se colocan las Ip o Endponit o URL de las API  que voy a consumir */

export const environment ={
    // en este espacio se declaran todas las url del proyecto 
    production: false,
    base_url: 'http://localhost:5000/api/v1',
};