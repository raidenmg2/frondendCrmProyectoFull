export const environment ={
    // en este espacio se declaran todas las url del proyecto 
    production: true,
    base_url: 'http://localhost:5000/api/v1',
};