import { ROLES } from '../../app/core/enum/roles.enum';

export const config = {
  roles: [
     ROLES.ADMIN,
     ROLES.GERENTE,
     ROLES.USUARIO,
     ROLES.VENDEDOR,
    ],
};
